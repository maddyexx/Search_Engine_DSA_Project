#include <iostream>
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\Chaining.h"
using namespace std;

int main()
{
    Chaining t;
    int choice;
    t.start();
    do
    {
           cout<<"          ---< WELCOME TO TRAVEL HOLIC >---     "<<endl;
    cout<<"-------------------------------------------------------------"<<endl;
    cout<<"Press 1 --> To Add a Hotel Name and Location.."<<endl;
    cout<<"Press 2 --> To Search a Hotel Name and Location.."<<endl;
    cout<<"Press 3 --> To Delete a Hotel Name and Location.."<<endl;
    cout<<"Press 4 --> To Display Hotel Names with Location.."<<endl;
    cout<<"Press 5 --> To Increase Size of DataBase.."<<endl;
    cout<<"Press 6 --> Clear Screen.."<<endl;
    cout<<"Press 7 --> To Exit.."<<endl;
    cout<<"-------------------------------------------------------------"<<endl;
    cin>>choice;
    switch(choice)
    {
    case 1:
        {
            cout<<"\n\n";
            string full;
            int id;
            cout<<"Enter a Hotel Name & Location to Add"<<endl;
            cin.ignore();
            getline(cin,full);
            cout<<"Enter a Hotel Id"<<endl;
            cin>>id;
            t.Add(full,id);
            cout<<"\nName & Location Added\n\n"<<endl;
            if(t.CheckLoad())
            {
                t=t.Rehash(t);
            }
            break;
        }
    case 2:
        {
            cout<<"\n\n";
            int id;
            cout<<"Enter a Hotel Id to Search "<<endl;
            cin>>id;
            t.Search(id);
            cout<<"\n\n";
            break;
        }
    case 3:
        {
            cout<<"\n\n";
            int val;
            cout<<"Enter a Hotel ID to Delete "<<endl;
            cin>>val;
            t.Deletion(val);
            break;
        }
    case 4:
        {
            cout<<"\n\n------< All Hotel Names with Location >------\n\n";
            if(t.IsEmpty())
                cout<<"\n\nDataBase is Empty!..\n\n";
            else
            t.Display();
            cout<<"\n\n";
            break;
        }
    case 5:
        {
            t=t.Rehash(t);
			cout<<"\n\nDataBase Size Increased\n\n"<<endl;
			break;
        }
    case 6:
        {
			system("cls");
			break;
        }
    case 7:
        {
            cout<<"\n\n";
            cout<<"-------------------------------"<<endl;
            cout<<"Thanks For Visiting Us..."<<endl;
            cout<<"-------------------------------"<<endl;
            cout<<"\n\n";
            break;
        }
    default:
        {
            cout<<"Enter a Valid Number"<<endl;
        }
    }
    }while(choice!=7);
    return 0;
}
