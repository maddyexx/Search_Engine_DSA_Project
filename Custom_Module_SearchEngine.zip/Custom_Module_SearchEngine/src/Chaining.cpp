#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\Chaining.h"
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\leaf.h"
#include <iostream>
#include <windows.h>
using namespace std;
Chaining::Chaining()
{
    Size=20;
    arr = new AVL[Size];
}
Chaining::Chaining(int s)
{
    Size=s;
    arr = new AVL[Size];
}
Chaining::~Chaining()
{
}
bool Chaining::CheckLoad()
{
    bool check = false;
    for(int i = 0;i<Size;i++)
    {
    if(arr->IsLoaded(arr[i].Getroot()) > 50)
    {
        check = true;
    }
    else
    {
        check = false;
        return check;
    }
    }
    return check;
}
int Chaining::Hash(int data)
{
    return (data%Size);
}
int Chaining::DoubleHashing(int val)
{
        return  7- ( val%7);
}
int Chaining::Add(string val,int id)
{
    int index;
    index = Hash(id);
    int index2=DoubleHashing(id);
    if(arr[index].IsLoaded(arr->Getroot()) > 5)
       return arr[index].Add(val,id);
    else
       return arr[index2].Add(val,id);
}
void Chaining::Deletion(int id)
{
    int index;
    index = Hash(id);
    int index2=DoubleHashing(id);
    arr[index2].Remove(id);
    arr[index].Remove(id);
}
void Chaining::Display()
{
    for(int index=0; index<Size; index++)
    {
        arr[index].display();
    }
    arr->PrintFile();
}
void Chaining::start()
{
	system("Color F0");
	cout<<"\n\n\n\n\n\n\n\n\n";
//	cout<<"\t\t\t\t\t\t----------------------------\n";
	cout<<"\t\t\t\t\t    ----------------------------\n";
	cout<<"\t\t\t\t\t\t   Travel Holic\n";
	cout<<"\t\t\t\t\t    ----------------------------\n\n";
	cout<<"\t\t\t\t\tLoading ";
	char x = 219;
	for(int i=0; i<35; i++)
	{
		cout<<x;
		if(i<10)
		Sleep(50);
		if(i>=10 && i<20)
		Sleep(50);
		if(i>=10)
		Sleep(25);
	}
	system("cls");

}
bool Chaining::IsEmpty()
{
    int count=1;
    for(int index=0; index<Size; index++)
    {
        if(arr[index].IsLoaded(arr->Getroot()) == 0)
            count=0;
    }
    if(count==1)
        return true;
    else
        return false;
}
void Chaining::Search(int val)
{
    int index = Hash(val);
    int index2 = DoubleHashing(val);
    if(arr[index].Search(val))
    {
        cout<<"\n\nHotel Name Found\n\n";
    }
    else if(arr[index2].Search(val))
    {
        cout<<"\n\nHotel Name Found\n\n";
    }
    else
    {
        cout<<"\n\nSorry!.. Hotel Name Not Found!!!\n\n";
    }
}
Chaining Chaining::Rehash(Chaining C1)
{
       Chaining C2(Size+5);
    for (int i = 0; i < Size; i++)
        {
        if (arr[i].Getroot() != NULL)
            {
                C2.Preordertraversal(arr[i].Getroot());
            }
        }
    return C2;
}
void Chaining::Preordertraversal(leaf* temp)
{
    if(temp == NULL)
    {
        return;
    }
        string val=temp->Getval();
        int id=temp->Getdata();
        Add(val,id);
        Preordertraversal(temp->Getleft());
        Preordertraversal(temp->Getright());
}
