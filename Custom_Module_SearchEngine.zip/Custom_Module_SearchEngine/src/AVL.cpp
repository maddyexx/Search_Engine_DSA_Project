#include <iostream>
#include <fstream>
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\leaf.h"
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\AVL.h"
using namespace std;
AVL::AVL()
{
    root=NULL;
}

AVL::~AVL()
{
    //dtor
}
int AVL::IsLoaded(leaf* root)
{
    if(root == NULL)
        return 0;
    if(root->Getleft() == NULL && root->Getright() == NULL)
        return 1;
    else
        return IsLoaded(root->Getleft())+
            IsLoaded(root->Getright());
}
leaf* AVL::NewLeaf(string x, int val)
{
    leaf* New = new leaf(x);
    New->Setleft(NULL);
    New->Setright(NULL);
    New->Setheight(1);
    New->Setdata(val);  // new leaf is initially
                      // added at leaf
    return(New);
}
leaf* AVL::Insert(leaf* Root, int val,string x)
{
    /* 1. Perform the normal BST insertion */
    if (Root == NULL)
        return(NewLeaf(x,val));
    if (val == Root->Getdata())
    {
        cout<<"Hotel with this Id already exist .... ! Try Again with change Id"<<endl;
    }
    else if (val < Root->Getdata())
    {
        Root->Setleft(Insert(Root->Getleft(), val,x));
    }
    else if (val > Root->Getdata())
    {
        Root->Setright(Insert(Root->Getright(), val,x));
    }
    else
        return Root;

    /* 2. Update height of this ancestor Root */
    Root->Setheight( 1 + max(height(Root->Getleft()),
                        height(Root->Getright())));

    /* 3. Get the balance factor of this ancestor
        Root to check whether this Root became
        unbalanced */
    int Balance = balance(Root);

    // If this Root becomes unbalanced, then
    // there are 4 cases

    // Left Left Case
    if (Balance > 1 && val < Root->Getleft()->Getdata())
        return RotateRight(Root);

//     Right Right Case
    else if (Balance < -1 && val > Root->Getright()->Getdata())
        return RotateLeft(Root);

//     Left Right Case
    else if (Balance > 1 && val > Root->Getleft()->Getdata())
    {
        return doubleRightRotate(Root);
    }

//     Right Left Case
    else if (Balance < -1 && val < Root->Getright()->Getdata())
    {
        return doubleLeftRotate(Root);
    }

    /* return the (unchanged) Root pointer */
    return Root;
}
leaf* AVL::Delete(int x, leaf* t)
    {
        leaf* temp;

        // Element not found
        if(t == NULL)
        {
            //cout<<"\n\nSorry!.. Hotel Name Not Found!!!\n\n";
            return NULL;
        }

        // Searching for element
        else if(x < t->Getdata())
            t->Setleft(Delete(x, t->Getleft()));
        else if(x > t->Getdata())
            t->Setright(Delete(x, t->Getright()));

        // Element found
        // With 2 children
        else if(t->Getleft() && t->Getright())
        {
            temp = min(t->Getright());
            t->Setdata(temp->Getdata());
            t->Setright(Delete(t->Getdata(), t->Getright()));
            cout<<"\n\nHotel Name Deleted\n\n";
        }
        // With one or zero child
        else
        {
            temp = t;
            if(t->Getleft() == NULL)
                t = t->Getright();
            else if(t->Getright() == NULL)
                t = t->Getleft();
            delete temp;
            cout<<"\n\nHotel Name Deleted\n\n";
        }
        if(t == NULL)
            return t;

            t->Setheight(max(height(t->Getleft()), height(t->Getright()))+1);

        // If node is unbalanced
        // If left node is deleted, right case
        if(height(t->Getleft()) - height(t->Getright()) == -2)
        {
            // right right case
            if(height(t->Getright()->Getright()) - height(t->Getright()->Getleft()) == 1)
                return RotateLeft(t);
            // right left case
            else
                return doubleLeftRotate(t);
        }
        // If right node is deleted, Getleft() case
        else if(height(t->Getright()) - height(t->Getleft()) == 2)
        {
            // left left case
            if(height(t->Getleft()->Getleft()) - height(t->Getleft()->Getright()) == 1){
                return RotateRight(t);
            }
            // left right case
            else
                return doubleRightRotate(t);
        }
}
bool AVL::Search(int key)
{
    if(root == NULL)
    {
        return false;
    }
    else
    {
        leaf* temp= root;
        while(temp!= NULL)
        {
            if(temp->Getdata() == key)
            {
//                cout<<"\n\n";
//                cout<<temp->Getval()<<" Found at this "<<temp<<" Location"<<endl;
                return true;
            }
            else if(temp->Getdata() > key)
            {
                temp=temp->Getleft();
            }
            else
            {
                temp=temp->Getright();
            }
        }
//        cout<<"\n\n";
//        cout<<key<<" not Found"<<endl;
        return false;
    }
}
int AVL::height(leaf* Root)
{
    if(Root == NULL)
        return 0;

        return Root->Getheight();
}
int AVL::balance(leaf* Root)
{
    if(Root == NULL)
        return 0;

    return height(Root->Getleft()) - height(Root->Getright());
}
leaf* AVL::RotateRight(leaf* t)
{
        if (t->Getleft() != NULL) {
			leaf* u = t->Getleft();
			t->Setleft(u->Getright());
			u->Setright(t);
			t->Setheight(max(height(t->Getleft()), height(t->Getright())) + 1);
			u->Setheight(max(height(u->Getleft()), t->Getheight()) + 1);
			return u;
		}
		return t;
}
leaf* AVL::RotateLeft(leaf* t)
{
    if (t->Getright() != NULL) {
		    leaf* u = t->Getright();
		    t->Setright(u->Getleft());
		    u->Setleft(t);
		    t->Setheight(max(height(t->Getleft()), height(t->Getright())) + 1);
		    u->Setheight(max(height(t->Getright()), t->Getheight()) + 1);
		    return u;
            }
            return t;
}
leaf* AVL::doubleLeftRotate(leaf* t)
{
    t->Setright(RotateRight(t->Getright()));
    return RotateLeft(t);
}

leaf* AVL::doubleRightRotate(leaf* t)
{
    t->Setleft(RotateLeft(t->Getleft()));
    return RotateRight(t);
}
int AVL::max(int a,int b) //preSuccessor
{
        return (a > b)? a : b;
}
leaf* AVL::min(leaf* Root) //preDeccessor
{
		if(Root->Getleft()==NULL)
            return Root;
        else
            min(Root->Getleft());
}
void AVL::PrintPreorder(leaf* Root)
{
    ofstream fout;
    fout.open("travel-holic.txt", ios::app);
    if(Root == NULL)
    {
        return;
    }
        fout<<Root->Getval()<<endl;
        PrintPreorder(Root->Getleft());
        PrintPreorder(Root->Getright());
        fout.close();
}
void AVL::PrintFile()
{
    string val;
    ifstream fin;
    fin.open("travel-holic.txt");

    while (fin) {

        getline(fin, val);
        cout <<"--> "<< val<<"\n\n";
    }

    fin.close();
}
