#include <iostream>
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\leaf.h"
using namespace std;
leaf::leaf(string x)
{
    val=x;
    left=NULL;
    right=NULL;
    height=0;
    data=NULL;
}

leaf::~leaf()
{
    //dtor
}
