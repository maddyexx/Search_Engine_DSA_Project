#ifndef CHAINING_H
#define CHAINING_H
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\AVL.h"
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\leaf.h"
class Chaining
{
    public:
        Chaining();
        Chaining(int);
        virtual ~Chaining();
        int GetSize() { return Size; }
        void SetSize(int val) { Size = val; }
        AVL* Getarr() { return arr; }
        void Setarr(AVL* val) { arr = val; }
        int Hash(int);
        bool CheckLoad();
        void start();
        int scanNum(string);
        int DoubleHashing(int);
        int Add(string,int);
        void Deletion(int);
        void Search(int);
        void Display();
        bool IsEmpty();
        Chaining Rehash(Chaining);
        void Preordertraversal(leaf*);
    private:
        int Size;
        AVL* arr;
};

#endif // CHAINING_H
