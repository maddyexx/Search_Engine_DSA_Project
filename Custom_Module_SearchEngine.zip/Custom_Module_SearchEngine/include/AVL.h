#ifndef AVL_H
#define AVL_H
#include "C:\Users\hamma\OneDrive\Documents\C++\Custom_Module_SearchEngine\include\leaf.h"

class AVL
{
    public:
        AVL();

        virtual ~AVL();

        leaf* Getroot() { return root; }
        void Setroot(leaf* val) { root = val; }
        leaf* Insert(leaf*,int,string);
        int Add(string x,int id)
        {
        Setroot(Insert(Getroot(),id,x));
        static int count;
        return count + 1;
        }
        leaf* Remove(int x)
        {
            leaf* temp = Delete(x,Getroot());
            Setroot(temp);
            return temp;
        }
        bool Search(int);
        int IsLoaded(leaf*);
        leaf* Delete(int, leaf*);
        int balance(leaf*);
        leaf* RotateRight(leaf*);
        leaf* RotateLeft(leaf*);
        leaf* doubleLeftRotate(leaf*);
        leaf* doubleRightRotate(leaf*);
        int max(int a,int b);
        leaf* min(leaf*);
        int  height(leaf*);
        leaf* NewLeaf(string,int);
        void PrintPostorder(leaf*);
        void PrintInorder(leaf*);
        void PrintFile();
        void display()
        {
            PrintPreorder(Getroot());
        }
        void PrintPreorder(leaf*);
    protected:

    private:
        leaf* root; //!< Member variable "root"
};

#endif // AVL_H
