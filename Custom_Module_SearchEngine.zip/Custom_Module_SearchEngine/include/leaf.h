#ifndef LEAF_H
#define LEAF_H
#include <iostream>
using namespace std;


class leaf
{
    public:

        leaf(string);

        virtual ~leaf();

        int Getdata() { return data; }
        void Setdata(int val) { data = val; }
        string Getval() { return val; }
        void Setval(int v) { val = v; }
        leaf* Getleft() { return left; }
        void Setleft(leaf* val) { left = val; }
        leaf* Getright() { return right; }
        void Setright(leaf* val) { right = val; }
        int Getheight() { return height; }
        void Setheight(int val) { height = val; }
    protected:

    private:
        int height;
        int data; //!< Member variable "data"
        leaf* left; //!< Member variable "left"
        leaf* right; //!< Member variable "right"
        string val;
};

#endif // LEAF_H
